import java.util.Scanner;

public class ColumnarTransCip {

    private static Scanner in;

    public static void main(String[] args){
        System.out.println("-------------------------------");
        System.out.println(" Columnar Transposition Cipher ");
        System.out.println("-------------------------------");
        in = new Scanner(System.in);

        System.out.print("1. Enkripsi\n2. Dekripsi\nPilih (1 atau 2): ");
        int choice = in.nextInt();
        in.nextLine();

        if (choice == 1){
            System.out.println("Enkripsi");
            encryption();

        } else if (choice == 2){
            System.out.println("Dekripsi");
            decryption();

        } else {
            System.out.println("Pilihan Gagal");
            System.exit(0);
        }
    }

    private static void encryption(){
        System.out.print("Pesan: ");
        String plainText = in.nextLine().toUpperCase().replace(" ", "");
        StringBuilder msg = new StringBuilder(plainText);

        System.out.print("Kata Kunci: ");
        String keyword = in.nextLine().toUpperCase();

        
        int[] kywrdNumList = keywordNumAssign(keyword);

        
        for (int i = 0, j = 1; i < keyword.length(); i++, j++) {
            System.out.print(keyword.substring(i, j) + " ");
        }
        System.out.println();

        for (int i: kywrdNumList){
            System.out.print(i + " ");

        }

        System.out.println();
        System.out.println("-------------------------------");
        int extraLetters = msg.length() % keyword.length();
        int dummyCharacters = keyword.length() - extraLetters;

        if (extraLetters != 0){
            for (int i = 0; i < dummyCharacters; i++) {
                msg.append("_");
            }
        }

        int numOfRows = msg.length() / keyword.length();

    
        char[][] arr = new char[numOfRows][keyword.length()];

        int z = 0;
        for (int i = 0; i < numOfRows; i++) {
            for (int j = 0; j < keyword.length(); j++) {
                arr[i][j] = msg.charAt(z);
                z++;
            }

        }

        for (int i = 0; i < numOfRows; i++) {
            for (int j = 0; j < keyword.length(); j++) {
                System.out.print(arr[i][j] + " ");
            } 
            System.out.println();
        }

  
        StringBuilder cipherText = new StringBuilder();

        System.out.println();
  
        String numLoc = getNumberLocation(keyword, kywrdNumList);
        System.out.println("Location of numbers: " + numLoc);
        System.out.println();

        for (int i = 0, k = 0; i < numOfRows; i++, k++) {
            int d;
            if (k == keyword.length()){
                break;
            } else {
                d = Character.getNumericValue(numLoc.charAt(k));
            }
            for (int j = 0; j < numOfRows; j++) {
                cipherText.append(arr[j][d]);
            }
        }

        System.out.println("Cipher Text: " + cipherText);

    } 

    private static void decryption(){


        System.out.print("Pesan: ");
        String msg = in.nextLine().toUpperCase().replace(" ", "");

        System.out.print("Kata Kunci: ");
        String keyword = in.nextLine().toUpperCase();

        int numOfRows = msg.length() / keyword.length();

       
        char[][] arr = new char[numOfRows][keyword.length()];


        int[] kywrdNumList = keywordNumAssign(keyword);

        String numLoc = getNumberLocation(keyword, kywrdNumList);

        for (int i = 0, k = 0; i < msg.length(); i++, k++) {
            int d = 0;
            if (k == keyword.length()){
                k = 0;
            } else {
                d = Character.getNumericValue(numLoc.charAt(k));
            }

            for (int j = 0; j < numOfRows; j++, i++) {
                arr[j][d] = msg.charAt(i);
            } // for loop
            --i;
        }



        StringBuilder plainText = new StringBuilder();

        for (int i = 0; i < numOfRows; i++) {
            for (int j = 0; j < keyword.length(); j++) {
                plainText.append(arr[i][j]);
            } 
        } 

        System.out.println("Plain Text: " + plainText);

    } 

    private static String getNumberLocation(String keyword, int[] kywrdNumList) {
        String numLoc = "";
        for (int i = 1; i < keyword.length() + 1; i++) {
            for (int j = 0; j < keyword.length(); j++) {
                if (kywrdNumList[j] == i){
                    numLoc += j;
                }
            }
        }
        return numLoc;
    } 

    private static int[] keywordNumAssign(String keyword) {
        String alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        int[] kywrdNumList = new int[keyword.length()];

        int init = 0;
        for (int i = 0; i < alpha.length(); i ++){
            for (int j = 0; j < keyword.length(); j++) {
                if (alpha.charAt(i) == keyword.charAt(j)){
                    init++;
                    kywrdNumList[j] = init;
                }
            }
        }
        return kywrdNumList;
    } 
} 